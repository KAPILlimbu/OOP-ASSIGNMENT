#include<iostream>
#define pi 3.14
using namespace std;
int main()
{
	float a,p,r;
	cin>>r;
	p=2*2.14*r;
	a=3.14*r*r;
	cout<<"perimeter is"<<p;
	cout<<"area is"<<a;
	return 0;
}