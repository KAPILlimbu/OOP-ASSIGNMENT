#include<iostream>
#include<math.h>
using namespace std;
int main()
{
  int x1,x2,y1,y2,x;
  cin>>x1>>x2>>y1>>y2;
  x=sqrt(pow(x2-x1,2))+(pow(y2-y1,2));
  cout<<"the distance is"<<x;
  return 0;
}